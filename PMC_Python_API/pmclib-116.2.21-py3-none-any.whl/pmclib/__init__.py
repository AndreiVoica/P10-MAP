import sys
import clr
from distutils.sysconfig import get_python_lib


sys.path.insert(0,f"{get_python_lib()}/pmclib")
clr.AddReference('PMCLIB')