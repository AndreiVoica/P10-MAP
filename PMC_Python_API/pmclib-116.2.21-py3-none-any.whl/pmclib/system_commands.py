from PMCLIB import SystemCommands as _sys  # pylint: disable=E0611
from PMCLIB import PMCRTN
from pmclib import pmc_types as pm
from pmclib.pmc_types import assert_type

__sys = _sys()


def auto_connect_to_pmc() -> bool:
    """ Automatically searches for and connects to the first available PMC

    Returns
    -------
        bool:
            True if connection sucess, False otherwise
    """
    return __sys.AutoSearchAndConnectToPMC()


def connect_to_pmc(ipAddr: str) -> bool:
    """ Connects to a specific PMC at the specified IP Address.

    Parameters
    ----------
    ipAddr : str
        IP Address to connect to

    Returns
    -------
    bool
        True if connection sucess, False otherwise
    """
    return __sys.ConnectToSpecificPMC(ipAddr)


def get_pmc_status() -> pm.PmcStatus:
    """ Gets the status of the PMC
    Returns
    -------
        PMCStatus:
            PMC Status
    """
    return pm.PmcStatus(__sys.GetPMCStatus())


def gain_mastership():
    """Attempts to gain mastership of the PMC
    """
    rtn = __sys.GainMastership()
    if rtn != PMCRTN.ALLOK:
        raise pm.PmcError(f" gain_mastership command failed with code {rtn} ({Enum.GetName(PMCRTN, rtn)})")


def release_mastership():
    """Release mastership of the PMC
    """
    rtn = __sys.ReleaseMastership()
    if rtn != PMCRTN.ALLOK:
        raise pm.PmcError(
            f" release_mastership command failed with code {rtn} ({Enum.GetName(PMCRTN, rtn)})")


def is_master():
    """check whether current program is the master of the PMC

    Returns
    -------
        bool:
            True if this program has mastership of the PMC. Otherwise, False
    """
    rtn = __sys.IsMaster()
    if rtn == 0:
        return True
    else:
        return False


def reboot_pmc():
    """Reboot the PMC
    """
    rtn = __sys.RebootPMC()
    if rtn != PMCRTN.ALLOK:
        raise pm.PmcError(f" reboot_pmc command failed with code {rtn} ({Enum.GetName(PMCRTN, rtn)})")


def get_flyway_physical_status(
    flyway_id: int
) -> pm.FlywayPhysicalStatus:
    """Get the current flyway physical status

    Parameters
    ----------
    flyway_id : int
        flyway id

    Returns
    ----------
    power_consumption : float :
        power consumption, in watts
    cpu_temp : float :
        CPU temperature, in celsius
    amlifier_temp : float :
        amplifier temperature, in celcius
    motor_temp : float :
        motor temperature, in celsius
    """
    assert_type(flyway_id, int, "flyway_id")
    
    rtn = __sys.GetFlywayPhysicalStatus(flyway_id)
    if rtn.PmcRtn != PMCRTN.ALLOK:
        raise pm.PmcError(
            f"get_flyway_physical_status command failed with code {rtn.PmcRtn} ({Enum.GetName(PMCRTN, rtn)})")
    return pm.FlywayPhysicalStatus(rtn.powerConsumptionW, rtn.cpuTempC, rtn.amplifierTempC, rtn.motorTempC)
