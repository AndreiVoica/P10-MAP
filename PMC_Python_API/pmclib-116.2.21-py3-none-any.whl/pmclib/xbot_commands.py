from PMCLIB import XBotCommands as _bot  # pylint: disable=E0611
from PMCLIB import PMCRTN
from System import Enum
from System import UInt16
from pmclib import pmc_types as pm
from pmclib.pmc_types import assert_type
from typing import List

__bot = _bot()


def activate_xbots():
    """Activate all xbots in the system

    Raises
    ------
    pmc_types.PmcError
        Raised when the command fails or is rejected by the PMC.
    """
    rtn = __bot.ActivateXBOTS()
    if rtn != PMCRTN.ALLOK:
        raise pm.PmcError(
            f" activate_xbots command failed with code {rtn} ({Enum.GetName(PMCRTN, rtn)})")


def deactivate_xbots():
    """Deactivate all Xbots

    Raises
    ------
    pmc_types.PmcError
        Raised when the command fails or is rejected by the PMC.
    """
    rtn = __bot.DeactivateXBOTS()
    if rtn != PMCRTN.ALLOK:
        raise pm.PmcError(
            f"deactivate_xbots command failed with code {rtn} ({Enum.GetName(PMCRTN, rtn)})")


def levitation_command(
    xbot_id: int,
    lev_mode: pm.LevitateOptions,
):
    """Levitate or land Xbot(s)

    Parameters
    ----------
    xbot_id : int
        0 = all XBots, otherwise, XBot ID of a single XBot
    lev_mode : pmc_types.LevitateOptions
        land or levitate

    Raises
    ------
    pmc_types.PmcError
        Raised when the command fails or is rejected by the PMC.
    """
    assert_type(xbot_id, int, "xbot_id")

    rtn = __bot.LevitationCommand(xbot_id, lev_mode)
    if rtn != PMCRTN.ALLOK:
        raise pm.PmcError(
            f" levitation_command command failed with code {rtn} ({Enum.GetName(PMCRTN, rtn)})")


def get_xbot_status(
    xbot_id: int,
    option: pm.FeedbackType = pm.FeedbackType.POSITION
) -> pm.XbotStatus:
    """ get the full xbot status, including the xbot state and position data

    Parameters
    ----------
    xbot_id : int
        Xbot ID
    option : FeedbackType :
        Which info to query from the mover.

    Returns
    -------
    xbot_state : XBotState :
        XBot state
    cmd_label : int :
        command label of the command the xbot is currently executing, unsigned 2 bytes
    force_mode : bool :
        true = xbot is operating in force mode; false = xbot is operating in position mode
    connected_to_group : bool :
        true = xbot is connected to a group; false = xbot is not connected to a group
    connected_group_id : int :
        if xbot is connected to a group, then it will provide the group ID.
    motion_buffer_blocked : bool :
        true = xbot's motion buffer is blocked; false = xbot's motion buffer is not blocked
    buffered_motion_count : int :
        number of motion commands stored in the xbot's buffer
    stereotype_id : int :
        Assigned stereotype ID, 0-255. -1 means stereotype is not supported
    xbot_type : XbotType :
        The Type of the XBot
    feedback_position_si : List[float] :
        Queried 6 axis data, x, y, z in meters, rx, ry, rz in rads

    Raises
    ------
    pmc_types.PmcError
        Raised when the command fails or is rejected by the PMC.
    """
    assert_type(xbot_id, int, "xbot_id")

    rtn = __bot.GetXbotStatus(xbot_id, int(option))
    if rtn.PmcRtn != PMCRTN.ALLOK:
        raise pm.PmcError(
            f"get_xbot_status command failed with code {rtn.PmcRtn} ({Enum.GetName(PMCRTN, rtn.PmcRtn)})")
    xpos = [x for x in rtn.FeedbackPositionSI]
    return pm.XbotStatus(pm.XbotState(rtn.XBOTState), rtn.cmdLabel, rtn.inForceMode, xpos, rtn.isConnectedToGroup, rtn.connectedGroupID,
                         rtn.isMotionBufferBlocked, rtn.bufferedMotionCount, rtn.stereotypeID, rtn.moverType)


# Typing for auto fill return value information for get_all_xbot_info
AllXbotInfo = List["pm.XbotInfo"]


def get_all_xbot_info(
    feedback_option: int
) -> AllXbotInfo:
    """Gets basic information about all XBots in the system in one command

    Parameters
    ----------
    feedback_option : int
        0: feedback position. 1: reference position

    Returns
    ----------
    A list of individual xbots datas, each one contains:
    x_pos : float :
        X Position in m
    y_pos : float :
        Y Position in m
    z_pos : float :
        Z Position in m
    rx_pos : float :
        Rx Position in rad
    ry_pos : float :
        Ry Position in rad
    rz_pos : float :
        Rz Position in rad
    xbot_state : XbotState :
        Xbot state
    xbot_id : int :
        Xbot ID
    xbot_type : XbotType :
        The type of the XBot

    Raises
    ----------
    pmc_types.PmcError
        Raised when the command fails or is rejected by the PMC.
    """
    assert_type(feedback_option, int, "feedback_option")

    rtn = __bot.GetAllXbotInfo(feedback_option)
    if rtn.PmcRtn != PMCRTN.ALLOK:
        raise pm.PmcError(
            f"get_all_xbot_info command failed with code {rtn.PmcRtn} ({Enum.GetName(PMCRTN, rtn.PmcRtn)})")
    all_xbot_info = rtn.AllXbotInfoList
    return [pm.XbotInfo(x.XPos, x.YPos, x.ZPos, x.RxPos,
                        x.RyPos, x.RzPos, x.XBotState, x.XbotID, x.XbotType) for x in all_xbot_info]


def linear_motion_si(
    xbot_id: int,
    target_x: float,
    target_y: float,
    max_speed: float,
    max_accel: float,
    cmd_lb: int = 0,
    pos_mode: pm.PositionMode = pm.PositionMode.ABSOLUTE,
    lin_path: pm.LinearPathType = pm.LinearPathType.DIRECT,
    final_speed: float = 0.0
) -> float:
    """ Sends a linear motion command to a single xbot in SI units

    Parameters
    ----------
    xbot_id : int
        Xbot ID
    target_x : float
        Target X position in (m)
    target_y : float
        Target Y position in (m)
    max_speed : float
        maximum speed in (m/s)
    max_accel : float
        maximum acceleration in (m/s^2)
    cmd_lb : int, optional
        command label, by default 0
    pos_mode : pmc_types.PositionMode, optional
        positioning mode, by default `pmc_types.PositionMode.ABSOLUTE`
    lin_path : pmc_types.LinearPathType, optional
        linear path type, by default `pmc_types.LinearPathType.DIRECT`
    final_speed : float, optional
        final speed, by default 0.0

    Returns
    -------
    float
        Travel time in seconds.

    Raises
    ------
    pmc_types.PmcError
        Raised when the command fails or is rejected by the PMC.
    """

    assert_type(cmd_lb, int, "cmd_lb")
    assert_type(xbot_id, int, "xbot_id")
    assert_type(pos_mode, pm.PositionMode, "pos_mode")
    assert_type(lin_path, pm.LinearPathType, "lin_path")

    rtn = __bot.LinearMotionSI(UInt16(cmd_lb), int(xbot_id),
                               int(pos_mode), int(lin_path),
                               float(target_x), float(target_y),
                               float(final_speed), float(max_speed),
                               float(max_accel))
    if rtn.PmcRtn != PMCRTN.ALLOK:
        raise pm.PmcError(
            f"linear_motion_si command failed with code {rtn.PmcRtn} ({Enum.GetName(PMCRTN, rtn.PmcRtn)})")
    return rtn.TravelTimeSecs


def interpolated_linear_motion_si(
    xbot_id: int,
    target_x: float,
    target_y: float,
    max_speed: float,
    max_accel: float,
    final_speed: float = 0.0
):
    """ Sends a linear motion command to a single xbot in SI units

    Parameters
    ----------
    xbot_id : int
        Xbot ID
    target_x : float
        Target X position in (m)
    target_y : float
        Target Y position in (m)
    max_speed : float
        maximum speed in (m/s)
    max_accel : float
        maximum acceleration in (m/s^2)
    final_speed : float, optional
        final speed, by default 0.0

    Raises
    ------
    pmc_types.PmcError
        Raised when the command fails or is rejected by the PMC.
    """
    assert_type(xbot_id, int, "xbot_id")

    rtn = __bot.InterpolatedLinearMotion(int(xbot_id),
                                         float(target_x), float(target_y),
                                         float(final_speed), float(max_speed),
                                         float(max_accel))
    if rtn != PMCRTN.ALLOK:
        raise pm.PmcError(
            f"linear_motion_si command failed with code {rtn.PmcRtn} ({Enum.GetName(PMCRTN, rtn.PmcRtn)})")


def auto_driving_motion_si(
    xbot_count: int,
    xbot_ids: List[int],
    targets_x: List[float],
    targets_y: List[float]
):
    """ Automatically route xbots to their target positions

    Parameters
    ----------
    xbot_count : int
        number of xbots
    xbot_ids : List[int]
        Target Y position in (m)
    targets_x : List[float]
        maximum speed in (m/s)
    targets_y : List[float]
        maximum acceleration in (m/s^2)

    Raises
    ------
    pmc_types.PmcError
        Raised when the command fails or is rejected by the PMC.
    """

    assert_type(xbot_count, int, "xbot_count")

    targets_x = [float(x) for x in targets_x]
    targets_y = [float(y) for y in targets_y]

    rtn = __bot.AutoDrivingMotionSI(
        xbot_count, 0, xbot_ids, targets_x, targets_y)
    if rtn != PMCRTN.ALLOK:
        raise pm.PmcError(
            f"auto_driving_motion_si command failed with code {rtn} ({Enum.GetName(PMCRTN, rtn)})")


def edit_motion_macro(
    option: pm.MotionMacroOptions,
    macro_id: int,
) -> pm.MotionMacroStatus:
    """ motion macro control (save, clear)

    Parameters
    ----------
    option : pmc_types.MotionMacroOptions
        option to select to clear, save, query the macro etc.
    macro_id : int
        macro ID, range from 128 to 191

    Returns
    -------
    macro_id : int :
        the ID of the macro that this tuple is describing
    macro_state : int :
        0 = macro is not saved (cannot be run); 2 = macro is saved (ready to run)
    stored_commands_count :int :
        the number of commands stored in this macro

    Raises
    ------
    pmc_types.PmcError
        Raised when the command fails or is rejected by the PMC.
    """

    assert_type(macro_id, int, "macro_id")
    assert_type(option, pm.MotionMacroOptions, "motion_macro_option")

    rtn = __bot.EditMotionMacro(option, macro_id)
    if rtn.PmcRtn != PMCRTN.ALLOK:
        raise pm.PmcError(
            f"edit_motion_macro command failed with code {rtn.PmcRtn} ({Enum.GetName(PMCRTN, rtn.PmcRtn)})")
    return pm.MotionMacroStatus(
        rtn.motionMacroStatus.macroID,
        rtn.motionMacroStatus.macroState,
        rtn.motionMacroStatus.storedCommandsCount
    )


def run_motion_macro(
    macro_id: int,
    xbot_id: int,
    cmd_lb: int = 0
):
    """ copies the motion commands stored in the macro into the specified xbot

    Parameters
    ----------
    macro_id : int
        motion macro ID, range from 128 to 191
    xbot_id : int
        target xbot ID
    cmd_lb : int, optional
        command label, by default 0

    Raises
    ------
    pmc_types.PmcError
        Raised when the command fails or is rejected by the PMC.
    """

    assert_type(cmd_lb, int, "cmd_lb")
    assert_type(xbot_id, int, "xbot_id")

    rtn = __bot.RunMotionMacro(UInt16(cmd_lb), macro_id, xbot_id)
    if rtn != PMCRTN.ALLOK:
        raise pm.PmcError(
            f"run_motion_macro command failed with code {rtn} ({Enum.GetName(PMCRTN, rtn)})")


def short_axes_motion_si(
    xbot_id: int,
    target_z: float,
    target_rx: float,
    target_ry: float,
    target_rz: float,
    speed_z: float,
    speed_rx: float,
    speed_ry: float,
    speed_rz: float,
    cmd_lb: int = 0,
    pos_mode: pm.PositionMode = pm.PositionMode.ABSOLUTE
) -> float:
    """ Sends a linear motion command to a single xbot in SI units

    Parameters
    ----------
    xbot_id : int
        Xbot ID
    target_z : float
        Target z position in (m)
    target_rx : float
        Target Rx position in (rad)
    target_ry : float
        Target Ry position in (rad)
    target_rz : float
        Target Rz position in (rad)
    speed_z : float
        max z speed, in (m/s)
    speed_rx : float
        max rx speed, in (rad/s)
    speed_ry : float
        max ry speed, in (rad/s)
    speed_rz : float
        max rz speed, in (rad/s)
    cmd_lb : int, optional
        command label, by default 0
    pos_mode : pmc_types.PositionMode, optional
        positioning mode, by default `pmc_types.PositionMode.ABSOLUTE`

    Returns
    -------
    float
        Travel time in seconds.

    Raises
    ------
    pmc_types.PmcError
        Raised when the command fails or is rejected by the PMC.
    """
    assert_type(cmd_lb, int, "cmd_lb")
    assert_type(xbot_id, int, "xbot_id")
    assert_type(pos_mode, pm.PositionMode, "pos_mode")

    rtn = __bot.ShortAxesMotionSI(UInt16(cmd_lb), int(xbot_id),
                                  int(pos_mode), float(target_z),
                                  float(target_rx), float(target_ry),
                                  float(target_rz), float(speed_z), float(speed_rx), float(speed_ry), float(speed_rz))
    if rtn.PmcRtn != PMCRTN.ALLOK:
        raise pm.PmcError(
            f"short_axes_motion_si command failed with code {rtn.PmcRtn} ({Enum.GetName(PMCRTN, rtn.PmcRtn)})")
    return rtn.TravelTimeSecs

def rotary_motion(
    xbot_id: int,
    target_rz: float,
    max_speed: float,
    max_accel: float,
    cmd_lb: int = 0,
    rot_mode: pm.RotationMode = pm.RotationMode.NO_ANGLE_WRAP,
) -> float:
    """ Sends a rotation motion command to a single xbot in SI units

    Parameters
    ----------
    xbot_id : int
        Xbot ID
    target_rz : float
        Target rz position in (rad)
    max_speed : float
        max rz speed, in (rad/s)
    max_accel : float
        max rz acceleration, in (rad/s^2)
    cmd_lb : int, optional
        command label, by default 0
    rot_mode : pmc_types.RotationMode, optional
        angle wrapping and rotation mode, by default `pmc_types.PositionMode.NO_ANGLE_WRAP`

    Returns
    -------
    float
        Travel time in seconds.

    Raises
    ------
    pmc_types.PmcError
        Raised when the command fails or is rejected by the PMC.
    """
    assert_type(cmd_lb, int, "cmd_lb")
    assert_type(xbot_id, int, "xbot_id")
    assert_type(rot_mode, pm.RotationMode, "pos_mode")

    rtn = __bot.RotaryMotionP2P(int(cmd_lb), int(xbot_id),
                                  int(rot_mode), float(target_rz),
                                  float(max_speed), float(max_accel))
    if rtn.PmcRtn != PMCRTN.ALLOK:
        raise pm.PmcError(
            f"rotary_motion command failed with code {rtn.PmcRtn} ({Enum.GetName(PMCRTN, rtn.PmcRtn)})")
    return rtn.TravelTimeSecs


def rotary_motion_timed_spin(
    xbot_id: int,
    rot_time: float,
    target_rz: float,
    max_speed: float,
    max_accel: float,
    cmd_lb: int = 0,
) -> float:
    """ Sends a linear motion command to a single xbot in SI units

    Parameters
    ----------
    xbot_id : int
        Xbot ID
    rot_time : float
        Time to rotate for (s)
    target_rz : float
        Final target rz position to stop when the rotation time is reached (rad)
    max_speed : float
        max rz speed, in (rad/s)
    max_accel : float
        max rz acceleration, in (rad/s^2)
    cmd_lb : int, optional
        command label, by default 0

    Returns
    -------
    float
        Travel time in seconds.

    Raises
    ------
    pmc_types.PmcError
        Raised when the command fails or is rejected by the PMC.
    """
    assert_type(cmd_lb, int, "cmd_lb")
    assert_type(xbot_id, int, "xbot_id")

    rtn = __bot.RotaryMotionTimedSpin(int(cmd_lb), int(xbot_id),
                                      float(target_rz), float(max_speed),
                                      float(max_accel), float(rot_time),)
    if rtn.PmcRtn != PMCRTN.ALLOK:
        raise pm.PmcError(
            f"rotary_motion_spin command failed with code {rtn.PmcRtn} ({Enum.GetName(PMCRTN, rtn.PmcRtn)})")
    return rtn.TravelTimeSecs


def stop_motion(
    xbot_id: int
):
    """ stop xbot(s) motion

    Parameters
    ----------
    xbot_id : int
        xbot ID, 0 = all Xbots

    Raises
    ------
    pmc_types.PmcError
        Raised when the command fails or is rejected by the PMC.
    """
    assert_type(xbot_id, int, "xbot_id")

    rtn = __bot.StopMotion(xbot_id)
    if rtn != PMCRTN.ALLOK:
        raise pm.PmcError(
            f"stop_motion command failed with code {rtn} ({Enum.GetName(PMCRTN, rtn)})")


def get_all_accident_xbots() -> List[int]:
    """ Gets the ID and count of all xbots that have been deactivated due to accidents

    Returns
    ----------
    List[int]
        list of XBot ids that have failed due to accident

    Raises
    ------
    pmc_types.PmcError
        Raised when the command fails or is rejected by the PMC.
    """
    rtn = __bot.GetAllAccidentXbots()
    if rtn.PmcRtn != PMCRTN.ALLOK:
        raise pm.PmcError(
            f"get_all_accident_xbots command failed with code {rtn.PmcRtn} ({Enum.GetName(PMCRTN, rtn.PmcRtn)})")
    fail_count = rtn.XBotCount
    pyRtn = []
    for index in range(0, fail_count):
        pyRtn.append(rtn.XBotIDsArray[index])
    return pyRtn


def recover_accident_xbot(
    xbot_id: int
):
    """ Recover the selected accident xbot

    Parameters
    ----------
    xbot_id : int
        ID of the Xbot to be recovered

    Raises
    ------
    pmc_types.PmcError
        Raised when the command fails or is rejected by the PMC.
    """
    assert_type(xbot_id, int, "xbot_id")

    rtn = __bot.RecoverAccidentXbot(xbot_id)
    if rtn != PMCRTN.ALLOK:
        raise pm.PmcError(
            f"recover_accident_xbot command failed with code {rtn} ({Enum.GetName(PMCRTN, rtn)})")